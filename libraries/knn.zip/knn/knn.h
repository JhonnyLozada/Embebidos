float knn(int fila, int col, int k, int label, float datos[]);
